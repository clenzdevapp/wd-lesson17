#!/usr/bin/env python
import os
import time
import jinja2
import webapp2


template_dir = os.path.join(os.path.dirname(__file__), "templates")
jinja_env = jinja2.Environment(loader=jinja2.FileSystemLoader(template_dir), autoescape=False)


class BaseHandler(webapp2.RequestHandler):

    def write(self, *a, **kw):
        return self.response.out.write(*a, **kw)

    def render_str(self, template, **params):
        t = jinja_env.get_template(template)
        return t.render(params)

    def render(self, template, **kw):
        return self.write(self.render_str(template, **kw))

    def render_template(self, view_filename, params=None):
        if params is None:
            params = {}
        template = jinja_env.get_template(view_filename)
        return self.response.out.write(template.render(params))


class MainHandler(BaseHandler):
    def get(self):
        return self.render_template("unitconverter.html")


class ResultHandler(BaseHandler):
    def post(self):
        number1 = int(self.request.get("zahl1"))
        number2 = int(self.request.get("zahl2"))
        operator = self.request.get("operator")
        result = 0

        if operator == "+":
            result = number1 + number2
        elif operator == "-":
            result = number1 - number2
        elif operator == "*":
            result = number1 * number2
        elif operator == "/":
            result = number1 / number2

        return self.write(result)

class ConverterHandler(BaseHandler):
    def post(self):
        kilometers = int(self.request.get("kilometers"))
        miles = kilometers * 0.621371
        return self.write(miles)

app = webapp2.WSGIApplication([
    webapp2.Route('/', MainHandler),
    webapp2.Route('/result', ResultHandler),
    webapp2.Route('/result2', ConverterHandler)
], debug=True)